<script>
    import { onMount } from "svelte";
    import { allBodies } from "../store.js";
    import Card from "../components/Card.svelte";

    let celestialBodies = [];
    let cards = [];
    let currentIndex = 0;

    const unsubscribe = allBodies.subscribe((value) => {
        celestialBodies = value;
    });

    function generateCards() {
        cards = [];
        let planetCount = 0;
        let moonCount = 0;
        let asteroidCount = 0;

        for (let i = currentIndex; i < celestialBodies.length; i++) {
            if (planetCount < 4 && celestialBodies[i].bodyType === "planet") {
                cards.push(celestialBodies[i]);
                planetCount++;
            } else if (
                moonCount < 4 &&
                celestialBodies[i].bodyType === "moon"
            ) {
                cards.push(celestialBodies[i]);
                moonCount++;
            } else if (
                asteroidCount < 4 &&
                celestialBodies[i].bodyType === "asteroid"
            ) {
                cards.push(celestialBodies[i]);
                asteroidCount++;
            }

            if (cards.length === 12) {
                currentIndex = i + 1;
                if (currentIndex >= celestialBodies.length) {
                    currentIndex = 0;
                }
                break;
            }
        }

        console.log("Generated cards:", cards);
    }

    onMount(() => {
        generateCards(); // Generate cards on mount
        return () => {
            unsubscribe();
        };
    });
</script>

<div class="card-container"></div>

<style>
    .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-items: flex-start;
        margin-top: 20px;
    }
</style>
