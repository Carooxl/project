<footer></footer>

<style>
    footer {
        color: #fff;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
</style>
